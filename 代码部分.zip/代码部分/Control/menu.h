#ifndef _MENU_H__
#define _MENU_H__
extern uint8_t Key_Num;
void Boot_animation(void);	
void menu_operation(void);		
void Homepage_1(void);
void Homepage_2(void);
void Homepage_3(void);
void Homepage_4(void);
#endif
